<?php
$conn = mysqli_connect("localhost", "root", "", "e-life");
session_start();

$user_check = $_SESSION['login_user'];
$query = "SELECT firstname from login where firstname='$user_check";

?>